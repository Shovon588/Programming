#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m,i,j,cnt=0,temp=1,x;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&x);
        cnt=cnt+x;
        a[i]=cnt;
    }
    scanf("%d",&m);
    int b[m];
    for(i=0;i<m;i++)
    {
        scanf("%d",&b[i]);
    }

    for(i=0;i<m;i++)
    {
        temp=1;
        for(j=0;j<n;j++)
        {
            if(b[i]>=temp && b[i]<=a[j])
            {
                printf("%d\n",j+1);
                break;
            }
            temp=a[j];
        }
    }




    return 0;
}
