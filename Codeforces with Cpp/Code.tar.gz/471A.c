#include<stdio.h>
#include<string.h>
int main()
{
	#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	#endif

    int a[10],i,count=0,j,b=1;
    for(i=0;i<6;i++)
    {
    	scanf("%d",&a[i]);
    }

    for(i=0;i<6;i++)
    {
    	for(j=i+1;j<6;j++)
    	{
    		if(a[i]==a[j])
    		{
    			b++;
    			if(b>count)
    			{
    				count=b;
    			}
    		}
    		else
    		{
    			b=1;
    		}
    	}
    }

    printf("%d\n",count );


	return 0;
}