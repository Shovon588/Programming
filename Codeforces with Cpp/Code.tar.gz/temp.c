#include<stdio.h>
#include<math.h>
int main()
{
	#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	#endif

    float a,b;
    scanf("%f",&a);

    b=sin((3.1416*a)/180);

    printf("%f\n",b );


}