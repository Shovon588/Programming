#include<stdio.h>
int main()
{
   	#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	#endif

	printf("Hello World\n");

}