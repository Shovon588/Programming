#include<stdio.h>
int main()
{
	#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	#endif

    int n,m,i;
    scanf("%d%d",&n,&m);

    for(i=0;i<n;i++)



   }