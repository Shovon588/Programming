#include<stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    printf("Hello IUT");
    for(i=0;i<n;i++)
    {
        printf("!");
    }


    return 0;
}
